import React from 'react';
import type { ViewStyle, StyleProp } from 'react-native';
import { type BlurType } from './ReactNativeVibrancyViewNativeComponent';
export interface VibrancyViewProps {
    /**
     * @description The type of blur effect to apply
     *
     * @default 'xlight'
     */
    blurType?: BlurType;
    /**
     * @description The intensity of the blur effect (0-100)
     *
     * @default 10
     */
    blurAmount?: number;
    /**
     * @description style object for the vibrancy view
     *
     * @default undefined
     */
    style?: StyleProp<ViewStyle>;
    /**
     * @description Child components to render inside the vibrancy view
     *
     * @default undefined
     */
    children?: React.ReactNode;
}
/**
 * A component that applies a vibrancy effect to its content.
 *
 * On iOS, this uses UIVibrancyEffect.
 * On Android, this falls back to a simple View (or BlurView behavior if implemented).
 */
export declare const VibrancyView: React.FC<VibrancyViewProps>;
//# sourceMappingURL=VibrancyView.d.ts.map