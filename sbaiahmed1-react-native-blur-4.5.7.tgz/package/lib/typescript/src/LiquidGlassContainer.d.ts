import React from 'react';
import { type ViewProps } from 'react-native';
export interface LiquidGlassContainerProps extends ViewProps {
    /**
     * The spacing value for the glass container effect
     * Platform: iOS only (iOS 26+)
     *
     * @default 0
     */
    spacing?: number;
}
/**
 * LiquidGlassContainer component
 *
 * A UIKit-based container that applies the iOS 26+ UIGlassContainerEffect.
 * This component uses the liquid glass container effect with configurable spacing.
 *
 * Platform: iOS only (iOS 26+)
 *
 * @platform ios
 *
 * @example
 * ```tsx
 * <LiquidGlassContainer spacing={20} style={{ flex: 1 }}>
 *   <Text>Content inside glass container</Text>
 * </LiquidGlassContainer>
 * ```
 */
export declare const LiquidGlassContainer: React.FC<LiquidGlassContainerProps>;
//# sourceMappingURL=LiquidGlassContainer.d.ts.map