import type { ViewProps } from 'react-native';
import type { WithDefault, Double } from 'react-native/Libraries/Types/CodegenTypes';
export type BlurType = 'xlight' | 'light' | 'dark' | 'extraDark' | 'regular' | 'prominent' | 'systemUltraThinMaterial' | 'systemThinMaterial' | 'systemMaterial' | 'systemThickMaterial' | 'systemChromeMaterial' | 'systemUltraThinMaterialLight' | 'systemThinMaterialLight' | 'systemMaterialLight' | 'systemThickMaterialLight' | 'systemChromeMaterialLight' | 'systemUltraThinMaterialDark' | 'systemThinMaterialDark' | 'systemMaterialDark' | 'systemThickMaterialDark' | 'systemChromeMaterialDark';
interface NativeProps extends ViewProps {
    blurAmount?: WithDefault<Double, 10.0>;
    blurType?: WithDefault<BlurType, 'xlight'>;
    reducedTransparencyFallbackColor?: WithDefault<string, '#FFFFFF'>;
    ignoreSafeArea?: WithDefault<boolean, true>;
}
declare const _default: import("react-native/Libraries/Utilities/codegenNativeComponent").NativeComponentType<NativeProps>;
export default _default;
//# sourceMappingURL=ReactNativeBlurViewNativeComponent.d.ts.map