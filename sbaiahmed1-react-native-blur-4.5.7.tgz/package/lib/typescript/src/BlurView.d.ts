import React from 'react';
import type { ViewStyle, StyleProp, ColorValue } from 'react-native';
import { type BlurType } from './ReactNativeBlurViewNativeComponent';
export interface BlurViewProps {
    /**
     * @description The type of blur effect to apply
     *
     * @default 'xlight'
     */
    blurType?: BlurType;
    /**
     * @description The intensity of the blur effect (0-100)
     *
     * @default 10
     */
    blurAmount?: number;
    /**
     * @description Fallback color when reduced transparency is enabled
     *
     * Accepts hex color strings like `#FFFFFF`
     *
     * @default '#FFFFFF'
     */
    reducedTransparencyFallbackColor?: string;
    /**
     * @description The overlay color to apply on top of the blur effect
     *
     * @default undefined
     */
    overlayColor?: ColorValue;
    /**
     * @description style object for the blur view
     *
     * @default undefined
     */
    style?: StyleProp<ViewStyle>;
    /**
     * @description style object for the blur view
     *
     * @default true
     */
    ignoreSafeArea?: boolean;
    /**
     * @description Child components to render inside the blur view
     *
     * @default undefined
     */
    children?: React.ReactNode;
}
/**
 * A cross-platform blur view component that provides native blur effects.
 *
 * On iOS, this uses UIVisualEffectView for true blur effects.
 * On Android, this uses the BlurView library for hardware-accelerated blur effects.
 *
 * This component automatically handles the proper positioning pattern where the blur
 * effect is positioned absolutely behind the content, ensuring interactive elements
 * work correctly.
 *
 * @example
 * ```tsx
 * <BlurView
 *   blurType="light"
 *   blurAmount={20}
 *   style={{ flex: 1 }}
 * >
 *   <Text>Content on top of blur</Text>
 *   <Button title="Interactive Button" onPress={() => {}} />
 * </BlurView>
 * ```
 */
export declare const BlurView: React.FC<BlurViewProps>;
export default BlurView;
//# sourceMappingURL=BlurView.d.ts.map